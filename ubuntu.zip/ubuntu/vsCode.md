打开终端，使用下列命令，通过官方PPA来安装Ubuntu Make：
sudo add-apt-repository ppa:ubuntu-desktop/ubuntu-make
sudo apt-get update
sudo apt-get install ubuntu-make


安装Ubuntu Make完后，接着使用下列命令安装Visual Studio Code：
umake web visual-studio-code


卸载Visual Studio Code
umake web visual-studio-code --remove