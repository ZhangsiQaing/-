describe tablename   查看表信息
describe 

8
12
13
14
15


## JOIN
1.1 INNER JOIN(内连接)
1.2 LEFT OUTER JOIN(左外连接)
1.3 OUTER JOIN(外连接)
1.4 RIGHT OUTER JOIN(右外连接)
1.5 FULL OUTER JOIN(完全外连接)
1.6 LEFT SEMI-JOIN(左半开连接)
1.7 笛卡儿积JOIN
1.8 map-side JOIN(map-side JOIN)


hive的连接博客
https://my.oschina.net/iamchenli/blog/845850



58pic_privilege        权限表
58pic_sponsor_order    订单表
58pic_user_activity    活动表
58pic_user_sc_pic      用户收藏表