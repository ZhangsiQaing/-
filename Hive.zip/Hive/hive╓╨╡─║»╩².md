





sort_array()  数组内部的排序操作


collect_set() 将多列合并为一个数组，和group by使用
concat_ws()   将多列合并为字符串